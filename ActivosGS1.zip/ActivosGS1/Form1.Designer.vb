﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class w_Formulario_Activos
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.lbl_titulo = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.txt_codigo_activo = New System.Windows.Forms.TextBox()
        Me.lbl_codigo_activo = New System.Windows.Forms.Label()
        Me.lbl_descripcion = New System.Windows.Forms.Label()
        Me.lbl_fecha_alta = New System.Windows.Forms.Label()
        Me.lbl_estatus = New System.Windows.Forms.Label()
        Me.lbl_origen = New System.Windows.Forms.Label()
        Me.txt_descripcion = New System.Windows.Forms.TextBox()
        Me.txt_fecha_alta = New System.Windows.Forms.DateTimePicker()
        Me.txt_estatus = New System.Windows.Forms.TextBox()
        Me.txt_origen = New System.Windows.Forms.TextBox()
        Me.btn_crear_activo = New System.Windows.Forms.Button()
        Me.btn_cancelar = New System.Windows.Forms.Button()
        Me.btn_buscar_activo = New System.Windows.Forms.Button()
        Me.txt_buscar = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.groupbox_nuevo_activo = New System.Windows.Forms.GroupBox()
        Me.groupbox_buscar_activo = New System.Windows.Forms.GroupBox()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.groupbox_nuevo_activo.SuspendLayout()
        Me.SuspendLayout()
        '
        'lbl_titulo
        '
        Me.lbl_titulo.AutoSize = True
        Me.lbl_titulo.Font = New System.Drawing.Font("Times New Roman", 26.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_titulo.Location = New System.Drawing.Point(155, 189)
        Me.lbl_titulo.Name = "lbl_titulo"
        Me.lbl_titulo.Size = New System.Drawing.Size(128, 40)
        Me.lbl_titulo.TabIndex = 0
        Me.lbl_titulo.Text = "Activos"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.ActivosGS1.My.Resources.Resources.GS1_GT
        Me.PictureBox1.Location = New System.Drawing.Point(139, 92)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(175, 94)
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'txt_codigo_activo
        '
        Me.txt_codigo_activo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_codigo_activo.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_codigo_activo.Location = New System.Drawing.Point(607, 84)
        Me.txt_codigo_activo.Name = "txt_codigo_activo"
        Me.txt_codigo_activo.Size = New System.Drawing.Size(198, 26)
        Me.txt_codigo_activo.TabIndex = 2
        '
        'lbl_codigo_activo
        '
        Me.lbl_codigo_activo.AutoSize = True
        Me.lbl_codigo_activo.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_codigo_activo.Location = New System.Drawing.Point(482, 83)
        Me.lbl_codigo_activo.Name = "lbl_codigo_activo"
        Me.lbl_codigo_activo.Size = New System.Drawing.Size(119, 19)
        Me.lbl_codigo_activo.TabIndex = 6
        Me.lbl_codigo_activo.Text = "Codigo de Activo:"
        '
        'lbl_descripcion
        '
        Me.lbl_descripcion.AutoSize = True
        Me.lbl_descripcion.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_descripcion.Location = New System.Drawing.Point(517, 124)
        Me.lbl_descripcion.Name = "lbl_descripcion"
        Me.lbl_descripcion.Size = New System.Drawing.Size(84, 19)
        Me.lbl_descripcion.TabIndex = 12
        Me.lbl_descripcion.Text = "Descripcion:"
        '
        'lbl_fecha_alta
        '
        Me.lbl_fecha_alta.AutoSize = True
        Me.lbl_fecha_alta.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_fecha_alta.Location = New System.Drawing.Point(524, 170)
        Me.lbl_fecha_alta.Name = "lbl_fecha_alta"
        Me.lbl_fecha_alta.Size = New System.Drawing.Size(77, 19)
        Me.lbl_fecha_alta.TabIndex = 16
        Me.lbl_fecha_alta.Text = "Fecha Alta:"
        '
        'lbl_estatus
        '
        Me.lbl_estatus.AutoSize = True
        Me.lbl_estatus.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_estatus.Location = New System.Drawing.Point(546, 210)
        Me.lbl_estatus.Name = "lbl_estatus"
        Me.lbl_estatus.Size = New System.Drawing.Size(55, 19)
        Me.lbl_estatus.TabIndex = 17
        Me.lbl_estatus.Text = "Estatus:"
        '
        'lbl_origen
        '
        Me.lbl_origen.AutoSize = True
        Me.lbl_origen.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_origen.Location = New System.Drawing.Point(546, 253)
        Me.lbl_origen.Name = "lbl_origen"
        Me.lbl_origen.Size = New System.Drawing.Size(53, 19)
        Me.lbl_origen.TabIndex = 18
        Me.lbl_origen.Text = "Origen:"
        '
        'txt_descripcion
        '
        Me.txt_descripcion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_descripcion.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_descripcion.Location = New System.Drawing.Point(607, 124)
        Me.txt_descripcion.Name = "txt_descripcion"
        Me.txt_descripcion.Size = New System.Drawing.Size(198, 26)
        Me.txt_descripcion.TabIndex = 19
        '
        'txt_fecha_alta
        '
        Me.txt_fecha_alta.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_fecha_alta.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.txt_fecha_alta.Location = New System.Drawing.Point(607, 168)
        Me.txt_fecha_alta.Name = "txt_fecha_alta"
        Me.txt_fecha_alta.Size = New System.Drawing.Size(198, 26)
        Me.txt_fecha_alta.TabIndex = 20
        '
        'txt_estatus
        '
        Me.txt_estatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_estatus.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_estatus.Location = New System.Drawing.Point(607, 211)
        Me.txt_estatus.Name = "txt_estatus"
        Me.txt_estatus.Size = New System.Drawing.Size(198, 26)
        Me.txt_estatus.TabIndex = 21
        '
        'txt_origen
        '
        Me.txt_origen.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_origen.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_origen.Location = New System.Drawing.Point(607, 253)
        Me.txt_origen.Name = "txt_origen"
        Me.txt_origen.Size = New System.Drawing.Size(198, 26)
        Me.txt_origen.TabIndex = 22
        '
        'btn_crear_activo
        '
        Me.btn_crear_activo.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btn_crear_activo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_crear_activo.Font = New System.Drawing.Font("Times New Roman", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_crear_activo.Location = New System.Drawing.Point(75, 272)
        Me.btn_crear_activo.Margin = New System.Windows.Forms.Padding(0)
        Me.btn_crear_activo.Name = "btn_crear_activo"
        Me.btn_crear_activo.Size = New System.Drawing.Size(127, 39)
        Me.btn_crear_activo.TabIndex = 23
        Me.btn_crear_activo.Text = "Crear Activo"
        Me.btn_crear_activo.UseVisualStyleBackColor = False
        '
        'btn_cancelar
        '
        Me.btn_cancelar.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.btn_cancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_cancelar.Font = New System.Drawing.Font("Times New Roman", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_cancelar.Location = New System.Drawing.Point(217, 272)
        Me.btn_cancelar.Margin = New System.Windows.Forms.Padding(0)
        Me.btn_cancelar.Name = "btn_cancelar"
        Me.btn_cancelar.Size = New System.Drawing.Size(96, 39)
        Me.btn_cancelar.TabIndex = 24
        Me.btn_cancelar.Text = "Cancelar"
        Me.btn_cancelar.UseVisualStyleBackColor = False
        '
        'btn_buscar_activo
        '
        Me.btn_buscar_activo.BackColor = System.Drawing.SystemColors.Info
        Me.btn_buscar_activo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_buscar_activo.Font = New System.Drawing.Font("Times New Roman", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_buscar_activo.Location = New System.Drawing.Point(286, 315)
        Me.btn_buscar_activo.Margin = New System.Windows.Forms.Padding(0)
        Me.btn_buscar_activo.Name = "btn_buscar_activo"
        Me.btn_buscar_activo.Size = New System.Drawing.Size(78, 36)
        Me.btn_buscar_activo.TabIndex = 25
        Me.btn_buscar_activo.Text = "Buscar"
        Me.btn_buscar_activo.UseVisualStyleBackColor = False
        '
        'txt_buscar
        '
        Me.txt_buscar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_buscar.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_buscar.Location = New System.Drawing.Point(85, 325)
        Me.txt_buscar.Name = "txt_buscar"
        Me.txt_buscar.Size = New System.Drawing.Size(198, 26)
        Me.txt_buscar.TabIndex = 26
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(85, 302)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(119, 19)
        Me.Label1.TabIndex = 27
        Me.Label1.Text = "Codigo de Activo:"
        '
        'groupbox_nuevo_activo
        '
        Me.groupbox_nuevo_activo.Controls.Add(Me.btn_crear_activo)
        Me.groupbox_nuevo_activo.Controls.Add(Me.btn_cancelar)
        Me.groupbox_nuevo_activo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.groupbox_nuevo_activo.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.groupbox_nuevo_activo.Location = New System.Drawing.Point(453, 44)
        Me.groupbox_nuevo_activo.Name = "groupbox_nuevo_activo"
        Me.groupbox_nuevo_activo.Size = New System.Drawing.Size(405, 329)
        Me.groupbox_nuevo_activo.TabIndex = 28
        Me.groupbox_nuevo_activo.TabStop = False
        Me.groupbox_nuevo_activo.Text = "Ingreso De Nuevo Activo"
        '
        'groupbox_buscar_activo
        '
        Me.groupbox_buscar_activo.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.groupbox_buscar_activo.Location = New System.Drawing.Point(67, 273)
        Me.groupbox_buscar_activo.Name = "groupbox_buscar_activo"
        Me.groupbox_buscar_activo.Size = New System.Drawing.Size(334, 100)
        Me.groupbox_buscar_activo.TabIndex = 29
        Me.groupbox_buscar_activo.TabStop = False
        Me.groupbox_buscar_activo.Text = "Buscar Activo "
        '
        'w_Formulario_Activos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(944, 455)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txt_buscar)
        Me.Controls.Add(Me.btn_buscar_activo)
        Me.Controls.Add(Me.txt_origen)
        Me.Controls.Add(Me.txt_estatus)
        Me.Controls.Add(Me.txt_fecha_alta)
        Me.Controls.Add(Me.txt_descripcion)
        Me.Controls.Add(Me.lbl_origen)
        Me.Controls.Add(Me.lbl_estatus)
        Me.Controls.Add(Me.lbl_fecha_alta)
        Me.Controls.Add(Me.lbl_descripcion)
        Me.Controls.Add(Me.lbl_codigo_activo)
        Me.Controls.Add(Me.txt_codigo_activo)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.lbl_titulo)
        Me.Controls.Add(Me.groupbox_nuevo_activo)
        Me.Controls.Add(Me.groupbox_buscar_activo)
        Me.Name = "w_Formulario_Activos"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Formulario Activos"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.groupbox_nuevo_activo.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbl_titulo As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents txt_codigo_activo As TextBox
    Friend WithEvents lbl_codigo_activo As Label
    Friend WithEvents lbl_descripcion As Label
    Friend WithEvents lbl_fecha_alta As Label
    Friend WithEvents lbl_estatus As Label
    Friend WithEvents lbl_origen As Label
    Friend WithEvents txt_descripcion As TextBox
    Friend WithEvents txt_fecha_alta As DateTimePicker
    Friend WithEvents txt_estatus As TextBox
    Friend WithEvents txt_origen As TextBox
    Friend WithEvents btn_crear_activo As Button
    Friend WithEvents btn_cancelar As Button
    Friend WithEvents btn_buscar_activo As Button
    Friend WithEvents txt_buscar As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents groupbox_nuevo_activo As GroupBox
    Friend WithEvents groupbox_buscar_activo As GroupBox
End Class
