﻿

Imports System.Net.Http 'Referencias'
Imports Newtonsoft.Json 'Administrador de paquetes NuGet'
Public Class w_Formulario_Activos

    Private baseUrl As String = "http://localhost:3000/api/gs1/activos" 'URL de tu backend
    Private Async Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Async Sub btn_crear_activo_Click(sender As Object, e As EventArgs) Handles btn_crear_activo.Click

        Dim nuevoActivo As New Dictionary(Of String, String) From {
           {"codigo_activo", txt_codigo_activo.Text},
           {"descripcion", txt_descripcion.Text},
           {"fecha_alta", txt_fecha_alta.Value.ToString("yyyy-MM-dd")},
           {"estatus", txt_estatus.Text},
           {"origen", txt_origen.Text}
       }

        Dim client As New HttpClient()

        Try
            Dim content As New StringContent(JsonConvert.SerializeObject(nuevoActivo), System.Text.Encoding.UTF8, "application/json")
            Dim response = Await client.PostAsync(baseUrl, content)

            If response.IsSuccessStatusCode Then
                MessageBox.Show("Activo agregado correctamente.")
                Limpiar_Campos_Activos()
            Else
                Dim errorMessage = Await response.Content.ReadAsStringAsync()
                MessageBox.Show("Error al agregar activo: " & errorMessage)
            End If
        Catch ex As Exception
            MessageBox.Show("Error al conectar con el servidor: " & ex.Message)
        End Try

    End Sub

    Private Async Sub btn_buscar_activo_Click(sender As Object, e As EventArgs) Handles btn_buscar_activo.Click

        Dim codigoActivo As String = txt_buscar.Text
        Dim client As New HttpClient()

        Try
            Dim response = Await client.GetAsync($"{baseUrl}/{codigoActivo}")

            If response.IsSuccessStatusCode Then
                Dim estado As String = Await response.Content.ReadAsStringAsync()
                MessageBox.Show($"Estado del activo: {estado}")
                txt_buscar.ResetText()
            Else
                Dim errorMessage = Await response.Content.ReadAsStringAsync()
                MessageBox.Show("Error al buscar estado del activo: " & errorMessage)
                txt_buscar.ResetText()
            End If
        Catch ex As Exception
            MessageBox.Show("Error al conectar con el servidor: " & ex.Message)
            txt_buscar.ResetText()
        End Try

    End Sub


    Private Sub btn_cancelar_Click(sender As Object, e As EventArgs) Handles btn_cancelar.Click
        Limpiar_Campos_Activos()
    End Sub

    Private Sub Limpiar_Campos_Activos() Handles PictureBox1.Click
        txt_codigo_activo.ResetText()
        txt_descripcion.ResetText()
        txt_fecha_alta.ResetText()
        txt_estatus.ResetText()
        txt_origen.ResetText()
    End Sub


End Class
